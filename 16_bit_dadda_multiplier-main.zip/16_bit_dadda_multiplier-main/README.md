# 16_bit_dadda_multiplier
high speed multiplier is implemented using the dadda algorithm and the 32 bit brent kung adder at the last stage.
